<?php

namespace App\Http\Controllers\Teacher;
use App\Http\Controllers\Controller;

class TeachersController extends Controller
{
    //
}
