<?php

namespace App\Models\Internship;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Internships_count_day extends Model
{
    protected $table = "internships_count_day";
}
