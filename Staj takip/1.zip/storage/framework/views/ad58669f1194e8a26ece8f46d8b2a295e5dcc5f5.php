<footer class="page-footer" style="background: transparent;margin-top: -2px;">
    <div class="container">
        <div class="links"><a style="margin-top: 30px;">Developed by TGATECH</a></div><a data-bss-hover-animate="bounce"
            href="https://github.com/TGDeity"><i class="icon ion-social-github" style="font-size: 25px;"></i></a>
        <div class="social-icons"></div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\staj\resources\views/front/include/body/unlogged/unlogged_guest_footer.blade.php ENDPATH**/ ?>