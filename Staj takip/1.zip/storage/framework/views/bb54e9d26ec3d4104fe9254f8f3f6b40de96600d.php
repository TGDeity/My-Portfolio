<!DOCTYPE html>
<html lang="tr">
<head>
    <?php echo $__env->yieldContent('meta'); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\Staj takip\resources\views/layouts/front.blade.php ENDPATH**/ ?>