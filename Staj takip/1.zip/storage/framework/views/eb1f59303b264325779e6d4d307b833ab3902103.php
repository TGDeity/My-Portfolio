<nav class="navbar navbar-dark navbar-expand-lg fixed-top bg-white portfolio-navbar gradient">
    <div class="container"><a class="navbar-brand logo" href="<?php echo e(route('index')); ?>">IKU</a><button data-bs-toggle="collapse"
            class="navbar-toggler" data-bs-target="#navbarNav"><span class="visually-hidden">Toggle
                navigation</span><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"></li>
                <li class="nav-item"></li>
                <li class="nav-item"></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a></li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /home/tgatechs/public_html/staj/resources/views/front/include/body/unlogged/unlogged_guest_navbar.blade.php ENDPATH**/ ?>