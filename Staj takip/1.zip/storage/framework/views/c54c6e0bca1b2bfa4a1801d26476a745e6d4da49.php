<!-- resources/views/components/layout.blade.php -->

<!-- HEAD TAGS -->
<?php $__env->startSection('meta'); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Staj Takip Sistemi</title>
<?php $__env->stopSection(); ?>
<!-- HEAD TAGS -->
<!-- CSS -->
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700&amp;display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>
<!-- CSS -->

<!-- BODY CONTENT -->
<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->guest()): ?>
        <?php echo $__env->make('front.include.body.unlogged.unlogged_guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <?php else: ?>
        <?php if(Auth::user()->authority_id == 1): ?>
            <?php echo $__env->make('front.include.body.logged.logged_student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <?php elseif(Auth::user()->authority_id == 2): ?>
            <?php echo $__env->make('front.include.body.logged.logged_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <?php elseif(Auth::user()->authority_id == 3): ?>
            <?php echo $__env->make('front.include.body.logged.logged_employer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<!-- BODY CONTENT -->

<!-- JS -->
<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('assets/js/student_index_init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<!-- JS -->

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\staj\resources\views/front/index.blade.php ENDPATH**/ ?>