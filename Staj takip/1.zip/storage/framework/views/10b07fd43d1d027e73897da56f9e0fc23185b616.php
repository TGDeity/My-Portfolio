<?php echo $__env->make('front.include.body.unlogged.unlogged_guest_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="page lanidng-page">
    <section class="portfolio-block website gradient">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-12 col-lg-5 offset-lg-1 text">
                    <h3>Staj Takip Uygulaması</h3>
                </div>
                <div class="col-md-12 col-lg-5">
                    <div class="portfolio-laptop-mockup">
                        <div class="screen">
                            <div class="screen-content"
                                style="background: url(&quot;<?php echo e(asset('assets/iku.jpg')); ?>&quot;);background-size: cover;">
                            </div>
                        </div>
                        <div class="keyboard"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php echo $__env->make('front.include.body.unlogged.unlogged_guest_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Staj takip\resources\views/front/include/body/unlogged/unlogged_guest.blade.php ENDPATH**/ ?>