<footer class="page-footer" style="background: transparent;margin-top: -2px;">
    <div class="container">
        <div class="links"><a href="#" style="margin-top: 30px;">Developed by TGATECH</a></div><a href="#"><i
                class="icon ion-social-github"></i></a>
        <div class="social-icons"></div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\Staj takip\resources\views/front/include/footer.blade.php ENDPATH**/ ?>