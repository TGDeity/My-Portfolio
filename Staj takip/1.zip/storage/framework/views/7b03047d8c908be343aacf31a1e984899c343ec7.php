<h1>LOGGED TEACHER INDEX</h1>
<a href="<?php echo e(route('logout')); ?>">ÇIKIŞ</a><?php /**PATH C:\xampp\htdocs\Staj takip\resources\views/front/include/body/logged_teacher.blade.php ENDPATH**/ ?>