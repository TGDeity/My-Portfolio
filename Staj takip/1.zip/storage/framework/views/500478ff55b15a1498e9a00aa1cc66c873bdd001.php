<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>404!</title>
    <script>
        function redirect() {
            setTimeout(() => {
                window.location.href = "/"
            }, 3000);

        }
        redirect();
    </script>
</head>





<?php $__env->startSection('meta'); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>404!</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div style="text-align: center">
        <img width="670px" height="670px" src="<?php echo e(asset('assets/images/404.jpg')); ?>" alt="Aranan sayfa bulunamadı">
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>
    <script>
        function redirect() {
            setTimeout(() => {
                window.location.href = "/"
            }, 3000);

        }
        redirect();
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tgatechs/public_html/staj/resources/views/errors/404.blade.php ENDPATH**/ ?>