<!DOCTYPE html>
<html lang="tr">
<head>
    <?php echo $__env->yieldContent('meta'); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>

<?php /**PATH /home/tgatechs/public_html/staj/resources/views/layouts/front.blade.php ENDPATH**/ ?>