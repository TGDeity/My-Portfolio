<h1>LOGGED TEACHER INDEX</h1>
<a href="<?php echo e(route('logout')); ?>">ÇIKIŞ</a><?php /**PATH C:\xampp\htdocs\staj\resources\views/front/include/body/logged/logged_teacher.blade.php ENDPATH**/ ?>