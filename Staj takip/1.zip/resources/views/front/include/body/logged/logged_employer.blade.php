<h1>LOGGED EMPLOYER INDEX</h1>
<a href="{{ route('logout') }}">ÇIKIŞ</a>