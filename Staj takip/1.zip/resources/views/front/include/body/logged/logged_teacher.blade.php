<h1>LOGGED TEACHER INDEX</h1>
<a href="{{ route('logout') }}">ÇIKIŞ</a>