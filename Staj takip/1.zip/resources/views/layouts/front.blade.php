<!DOCTYPE html>
<html lang="tr">
<head>
    @yield('meta')
    @yield('css')
</head>

<body>
    @yield('content')
    @yield('js')
</body>
</html>

